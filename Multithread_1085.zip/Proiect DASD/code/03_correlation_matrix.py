import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 1. Citirea datelor
df = pd.read_csv("../data/date_sgi.csv")

# 2. Selectam variabilele numerice
X = df.select_dtypes(include=["float64", "int64"])

# 3. Matricea de corelații
corr_matrix = X.corr()

# 4. Afișare numerica (opțional, util pentru verificare)
print("Matricea de corelatii:")
print(corr_matrix.round(2))

# 5. Heatmap
plt.figure(figsize=(14, 12))
sns.heatmap(
    corr_matrix,
    annot=True,
    fmt=".2f",
    cmap="coolwarm",
    center=0,
    linewidths=0.5
)

plt.title("Correlation Matrix of Variables")
plt.tight_layout()
plt.show()
