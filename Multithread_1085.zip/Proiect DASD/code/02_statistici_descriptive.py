import pandas as pd

pd.set_option("display.max_rows", None)
pd.set_option("display.max_columns", None)
pd.set_option("display.width", 120)
pd.set_option("display.precision", 2)
pd.set_option("display.float_format", "{:.2f}".format)


# 1. Citirea datelor
df = pd.read_csv("../data/date_sgi.csv")

# 2. Setam țarile ca index (opțional, dar recomandat)
df.set_index("Country", inplace=True)

# 3. Selectam doar variabilele numerice
X = df.select_dtypes(include=["float64", "int64"])

# 4. Statistici descriptive
desc = X.describe().T

# 5. Afișare
from tabulate import tabulate
print(tabulate(desc, headers="keys", tablefmt="grid"))

df.describe().T.to_excel("../output/tabel_statistici_descriptive.xlsx")



