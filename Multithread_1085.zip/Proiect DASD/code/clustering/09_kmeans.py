import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans

# =========================
# 1. Citim scorurile ACP
# =========================
scores_df = pd.read_csv("../../output/scores_pca.csv", index_col=0)

# folosim PC1 și PC2
X_kmeans = scores_df[["PC1", "PC2"]].copy()


# =========================
# 2. K-Means (k = 4)
# =========================
kmeans = KMeans(n_clusters=4, random_state=42, n_init=10)
clusters = kmeans.fit_predict(X_kmeans)

X_kmeans["Cluster"] = clusters

# =========================
# 3. Reprezentare grafică
# =========================
plt.figure(figsize=(10, 7))

scatter = plt.scatter(
    X_kmeans["PC1"],
    X_kmeans["PC2"],
    c=X_kmeans["Cluster"],
    cmap="viridis",
    s=70
)

# etichete tari
for country in X_kmeans.index:
    plt.text(
        X_kmeans.loc[country, "PC1"] + 0.05,
        X_kmeans.loc[country, "PC2"] + 0.05,
        country,
        fontsize=8
    )

plt.xlabel("PC1")
plt.ylabel("PC2")
plt.title("K-Means (k=4) în planul (PC1, PC2)")
plt.colorbar(scatter, label="Cluster")
plt.grid(True)
plt.tight_layout()
plt.show()
