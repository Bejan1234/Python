import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.cluster.hierarchy import dendrogram, linkage
from scipy.spatial.distance import pdist

# =========================
# 1. Citim scorurile ACP
# =========================

scores_df = pd.read_csv("../../output/scores_pca.csv", index_col=0)

# folosim primele 4 componente
cluster_data = scores_df.iloc[:, :4]

# =========================
# 2. Distanța Mahalanobis
# =========================

# matricea de covarianta
cov_matrix = np.cov(cluster_data.T)

# inversa covarianței
inv_cov_matrix = np.linalg.inv(cov_matrix)

# funcție distantă Mahalanobis
def mahalanobis_distance(u, v):
    delta = u - v
    return np.sqrt(delta @ inv_cov_matrix @ delta.T)

# calcul matrice distanțe
dist_matrix = pdist(cluster_data.values, metric=mahalanobis_distance)

# =========================
# 3. Clusterizare ierarhica
# =========================

Z = linkage(dist_matrix, method="complete")

# =========================
# 4. Dendrograma
# =========================

plt.figure(figsize=(10, 14))

dendrogram(
    Z,
    labels=cluster_data.index,
    orientation="right",
    leaf_font_size=9
)

plt.title("Dendrograma Observatii (Mahalanobis + Complete Linkage)")
plt.xlabel("Distanta")
plt.ylabel("Tari")
plt.tight_layout()
plt.show()
