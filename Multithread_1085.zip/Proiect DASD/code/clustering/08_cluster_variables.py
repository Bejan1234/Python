import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from scipy.cluster.hierarchy import dendrogram, linkage

# =========================
# 1. Citirea datelor
# =========================
df = pd.read_csv("../../data/date_sgi.csv")

# eliminăm coloana Country
X = df.drop(columns=["Country"])

# =========================
# 2. Standardizare
# =========================
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# =========================
# 3. Transpunere (variabilele devin observații)
# =========================
X_vars = X_scaled.T

# =========================
# 4. Clusterizare ierarhica
# =========================
Z = linkage(X_vars, method="average", metric="euclidean")

# =========================
# 5. Dendrograma variabile
# =========================
plt.figure(figsize=(10, 8))

dendrogram(
    Z,
    labels=X.columns,
    orientation="right",
    leaf_font_size=10
)

plt.title("Dendrograma Variabile (Euclidiana + Average Linkage)")
plt.xlabel("Distanta")
plt.ylabel("Variabile")
plt.tight_layout()
plt.show()
