import pandas as pd

# =========================
# 1. Citirea datelor
# =========================
df = pd.read_csv("../data/date_sgi.csv")

print("Primele 5 rânduri din dataset:")
print(df.head())

print("\nDimensiunea datasetului (linii, coloane):")
print(df.shape)

print("\nNumele coloanelor:")
print(df.columns.tolist())

# =========================
# 2. Verificare valori lipsă
# =========================
print("\nValori lipsă pe coloană:")
print(df.isnull().sum())

# =========================
# 3. Identificare coloană tari
# =========================
# presupunem că există o coloană cu țările
possible_country_cols = ["Country", "country", "Țară", "Tara"]

country_col = None
for col in possible_country_cols:
    if col in df.columns:
        country_col = col
        break

print("\nColoana cu țările:", country_col)

# =========================
# 4. Selectare variabile numerice
# =========================
numeric_df = df.select_dtypes(include=["float64", "int64"])

print("\nVariabile numerice:")
print(numeric_df.columns.tolist())
