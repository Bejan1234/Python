import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

# =========================
# 1. Citirea datelor
# =========================
df = pd.read_csv("../data/date_sgi.csv")
df.set_index("Country", inplace=True)

# =========================
# 2. Variabile numerice
# =========================
X = df.select_dtypes(include=["float64", "int64"])

# =========================
# 3. Standardizare
# =========================
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# =========================
# 4. PCA
# =========================
pca = PCA()
pca.fit(X_scaled)

# =========================
# 5. Valorile proprii
# =========================
eigenvalues = pca.explained_variance_

print("Valorile proprii:")
for i, val in enumerate(eigenvalues, start=1):
    print(f"Factor {i}: {val:.2f}")

# =========================
# 6. Scree Plot
# =========================
plt.figure(figsize=(8, 5))
plt.plot(range(1, len(eigenvalues) + 1), eigenvalues, marker='o')
plt.axhline(1, color='red', linestyle='--', label='Criteriul Kaiser (λ = 1)')
plt.xlabel("Factori")
plt.ylabel("Valori proprii")
plt.title("Scree Plot - Analiza Factorială")
plt.legend()
plt.tight_layout()
plt.show()

# =========================
# 7. Varianța explicata
# =========================
explained_variance_ratio = pca.explained_variance_ratio_ * 100
cumulative_variance = np.cumsum(explained_variance_ratio)

variance_df = pd.DataFrame({
    "Factor": [f"Factor {i}" for i in range(1, len(explained_variance_ratio) + 1)],
    "Varianță explicată (%)": explained_variance_ratio.round(2),
    "Varianță cumulată (%)": cumulative_variance.round(2)
})

print("\nVarianța totală explicată:")
print(variance_df)

# =========================
# 8. Diagramă pie – Varianță
# =========================
plt.figure(figsize=(8, 8))
plt.pie(
    explained_variance_ratio,
    labels=variance_df["Factor"],
    autopct='%1.1f%%',
    startangle=90
)
plt.title("Variance Explained by Factors")
plt.tight_layout()
plt.show()

# =========================
# 9. CORELAȚII FACTORIALE (echivalent PCA)
# =========================
# corelația variabilelor cu componentele
loadings = pd.DataFrame(
    pca.components_.T * np.sqrt(pca.explained_variance_),
    index=X.columns,
    columns=[f"Factor {i}" for i in range(1, len(X.columns) + 1)]
)

# păstrăm doar primii 5 factori
loadings_5 = loadings.iloc[:, :5]

print("\nCorelațiile factoriale:")
print(loadings_5.round(2))

# =========================
# 10. Corelograma corelațiilor factoriale
# =========================
plt.figure(figsize=(10, 8))
sns.heatmap(
    loadings_5,
    annot=True,
    cmap="coolwarm",
    center=0,
    fmt=".2f"
)
plt.title("Corelograma Corelațiilor Factoriale")
plt.tight_layout()
plt.show()
# 11. CERCUL CORELAȚIILOR FACTORIALE (Factor 1 vs Factor 2)
# =========================

# coordonatele variabilelor pe primii doi factori
coords = loadings_5.iloc[:, :2]

plt.figure(figsize=(8, 8))

# desenăm cercul unitate
theta = np.linspace(0, 2 * np.pi, 200)
plt.plot(np.cos(theta), np.sin(theta), linestyle='--', color='blue')

# axele
plt.axhline(0, color='gray', linewidth=1)
plt.axvline(0, color='gray', linewidth=1)

# punctele (variabilele)
plt.scatter(coords.iloc[:, 0], coords.iloc[:, 1], color='red')

# etichetele variabilelor
for i, var in enumerate(coords.index):
    plt.text(
        coords.iloc[i, 0] + 0.02,
        coords.iloc[i, 1] + 0.02,
        var,
        fontsize=9
    )

plt.xlabel("Factor 1")
plt.ylabel("Factor 2")
plt.title("Cercul Corelatiilor Factoriale - Factor 1 vs Factor 2")
plt.gca().set_aspect("equal", adjustable="box")
plt.grid(True)
plt.xlim(-1.1, 1.1)
plt.ylim(-1.1, 1.1)
plt.tight_layout()
plt.show()

# 12. CALITATEA REPREZENTARII OBSERVAȚIILOR (cos²)
# =========================

# scorurile PCA (coord. observațiilor)
scores = pca.transform(X_scaled)

scores_df = pd.DataFrame(
    scores[:, :5],  # primii 5 factori
    index=df.index,
    columns=[f"Factor {i}" for i in range(1, 6)]
)

# cos² = (scor^2) / suma scorurilor^2
cos2 = scores_df ** 2
cos2 = cos2.div(cos2.sum(axis=1), axis=0)

print("\nCalitatea reprezentarii observatiilor (cos²):")
print(cos2.round(3))
plt.figure(figsize=(10, 12))
sns.heatmap(
    cos2,
    cmap="YlOrRd",
    annot=True,
    fmt=".3f",
    cbar=True
)

plt.title("Corelograma Calitatii Reprezentarii Observatiilor")
plt.xlabel("Factori")
plt.ylabel("Observatii")
plt.tight_layout()
plt.show()
