import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
import os
os.makedirs("../output", exist_ok=True)
# =========================
# 1. Citirea datelor
# =========================
df = pd.read_csv("../data/date_sgi.csv")
df.set_index("Country", inplace=True)

# =========================
# 2. Selectam variabilele numerice
# =========================
X = df.select_dtypes(include=["float64", "int64"])

# =========================
# 3. Standardizare (OBLIGATORIU la ACP)
# =========================
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# =========================
# 4. PCA
# =========================
pca = PCA()
scores = pca.fit_transform(X_scaled)

# =========================
# 5. Varianța explicata
# =========================
explained_variance = pca.explained_variance_ratio_ * 100
cumulative_variance = np.cumsum(explained_variance)

variance_df = pd.DataFrame({
    "Componenta": [f"PC{i}" for i in range(1, len(explained_variance) + 1)],
    "Varianța explicata (%)": explained_variance.round(2),
    "Varianta cumulata (%)": cumulative_variance.round(2)
})

print("Varianța explicata de componentele principale:")
print(variance_df)

# =========================
# 6. Scree Plot – PCA
# =========================
plt.figure(figsize=(8, 5))
plt.plot(range(1, len(explained_variance) + 1), explained_variance, marker='o')

for i, val in enumerate(explained_variance):
    plt.text(i + 1, val + 0.5, f"{val:.2f}%", ha="center")

plt.xlabel("Componentă Principala")
plt.ylabel("Varianta Explicata (%)")
plt.title("Scree Plot - PCA")
plt.grid(True)
plt.tight_layout()
plt.show()

# =========================
# 7. Scorurile ACP (TOATE componentele)
# =========================
scores_df = pd.DataFrame(
    scores,
    index=df.index,
    columns=[f"PC{i}" for i in range(1, scores.shape[1] + 1)]
)

print("\nScoruri PCA (primele 5 rânduri):")
print(scores_df.head())

# =========================
# =========================
# Corelograma scorurilor PCA – CU VALORI
# =========================

plt.figure(figsize=(16, 12))

sns.heatmap(
    scores_df,
    cmap="coolwarm",
    center=0,
    annot=True,              # <<< CHEIA
    fmt=".2f",               # 2 zecimale, ca în PDF
    linewidths=0.3,
    linecolor="gray",
    cbar_kws={"label": "Scor PCA"}
)

plt.xlabel("Componente Principale")
plt.ylabel("Țări")
plt.title("Corelograma Scorurilor PCA")
plt.tight_layout()
plt.show()

# =========================
# Multi-histograma calității reprezentării observațiilor (cos²)
# =========================

# scoruri PCA
scores_df = pd.DataFrame(
    scores,
    index=df.index,
    columns=[f"PC{i}" for i in range(1, scores.shape[1] + 1)]
)

# cos² = scor^2 / suma scorurilor^2 pe linie
cos2 = scores_df**2
cos2 = cos2.div(cos2.sum(axis=1), axis=0)

# alegem primele 5 componente (ca în PDF)
cos2_sel = cos2.iloc[:, :5]

# =========================
# GRAFIC MULTI-HISTOGRAMĂ
# =========================
plt.figure(figsize=(18, 6))

x = np.arange(len(cos2_sel.index))
width = 0.15

for i, col in enumerate(cos2_sel.columns):
    plt.bar(
        x + i * width,
        cos2_sel[col],
        width,
        label=col
    )

plt.xticks(x + width*2, cos2_sel.index, rotation=60, ha="right")
plt.ylabel("Calitatea reprezentarii (cos²)")
plt.xlabel("Observații (Țări)")
plt.title("Multi-histograma calitații reprezentării observațiilor (PCA)")
plt.legend(title="Componente")

plt.tight_layout()
plt.show()

# =========================
# Corelograma factorilor de corelație
# (Variabile vs. Componente PCA – PC1–PC19)
# =========================

# 1. Calcul încărcături (corelații variabilă–componentă)
loadings = pca.components_.T * np.sqrt(pca.explained_variance_)

# 2. DataFrame cu TOATE componentele
loadings_df = pd.DataFrame(
    loadings,
    index=X.columns,
    columns=[f"PC{i}" for i in range(1, loadings.shape[1] + 1)]
)

print("Corelații variabile–componente (PC1–PC19):")
print(loadings_df)

# 3. Heatmap complet
plt.figure(figsize=(16, 10))

sns.heatmap(
    loadings_df,
    cmap="coolwarm",
    center=0,
    annot=True,
    fmt=".2f",
    vmin=-1,
    vmax=1,
    linewidths=0.3,
    linecolor="gray",
    cbar_kws={"label": "Coeficient de corelație"}
)

plt.xlabel("Componente Principale (PC1–PC19)")
plt.ylabel("Variabile")
plt.title("Corelograma Factorilor de Corelație (Variabile vs. Componente)")
plt.tight_layout()
plt.show()

# =========================
# Cercul corelațiilor (PC1 vs PC2)
# =========================

# 1. Calculam incarcaturile (corelațiile variabila–componenta)
loadings = pca.components_.T * np.sqrt(pca.explained_variance_)

# PC1 și PC2
pc1 = loadings[:, 0]
pc2 = loadings[:, 1]

plt.figure(figsize=(8, 8))

# 2. Desenam cercul unitate
theta = np.linspace(0, 2 * np.pi, 200)
plt.plot(np.cos(theta), np.sin(theta), linestyle='--', color='blue')

# 3. Axe
plt.axhline(0, color='gray')
plt.axvline(0, color='gray')

# 4. Vectorii variabilelor
for i, var in enumerate(X.columns):
    plt.arrow(
        0, 0,
        pc1[i], pc2[i],
        color='red',
        alpha=0.7,
        head_width=0.03,
        length_includes_head=True
    )
    plt.text(
        pc1[i] * 1.08,
        pc2[i] * 1.08,
        var,
        fontsize=9,
        color='green'
    )

plt.xlabel("PC1")
plt.ylabel("PC2")
plt.title("Cercul corelatiilor (PC1 vs PC2)")
plt.axis("equal")
plt.grid(True)
plt.tight_layout()
plt.show()


# =========================
# Corelograma comunalitaților componentelor principale (EXACT ca în PDF)
# =========================

# 1. Loadings PCA (corelatii variabilă–componenta)
loadings = pca.components_.T * np.sqrt(pca.explained_variance_)

loadings_df = pd.DataFrame(
    loadings,
    index=X.columns,
    columns=[f"PC{i}" for i in range(1, loadings.shape[1] + 1)]
)

# 2. Comunalitați = patratul loading-urilor (FĂRĂ cumul)
communalities = loadings_df ** 2

# =========================
# 3. Heatmap (identic PDF)
# =========================
plt.figure(figsize=(14, 9))

sns.heatmap(
    communalities,
    cmap="YlGnBu",
    annot=True,
    fmt=".2f",
    vmin=0,
    vmax=0.4,
    cbar_kws={"label": "Comunalitate"}
)

plt.xlabel("Componente Principale")
plt.ylabel("Variabile")
plt.title("Corelograma comunalitatilor componentelor principale")
plt.tight_layout()
plt.show()
# Salvăm scorurile ACP pentru analiza de cluster
scores_df.to_csv("../output/scores_pca.csv")

