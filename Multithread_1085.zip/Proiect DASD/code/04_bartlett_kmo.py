import pandas as pd
import matplotlib.pyplot as plt
from factor_analyzer.factor_analyzer import (
    calculate_bartlett_sphericity,
    calculate_kmo
)

# 1. Citirea datelor
df = pd.read_csv("../data/date_sgi.csv")

# 2. Variabile numerice
X = df.select_dtypes(include=["float64", "int64"])

# -------------------------
# Testul Bartlett
# -------------------------
chi_square_value, p_value = calculate_bartlett_sphericity(X)

print("Testul Bartlett de sfericitate")
print(f"Chi-pătrat: {chi_square_value:.3f}")
print(f"p-value: {p_value:.3e}")

# -------------------------
# Testul KMO
# -------------------------
kmo_all, kmo_model = calculate_kmo(X)

print("\nTestul KMO")
print(f"KMO global: {kmo_model:.4f}")

kmo_df = pd.DataFrame({
    "Variable": X.columns,
    "KMO": kmo_all
}).sort_values(by="KMO", ascending=True)

print("\nKMO per variabilă:")
print(kmo_df)

# -------------------------
# Grafic KMO
# -------------------------
plt.figure(figsize=(8, 10))
plt.barh(kmo_df["Variable"], kmo_df["KMO"],
         color=plt.cm.YlGn(kmo_df["KMO"]))

plt.axvline(0.5, color="red", linestyle="--", label="Prag KMO (0.5)")
plt.axvline(0.8, color="green", linestyle="--", label="Prag KMO (0.8)")

for i, v in enumerate(kmo_df["KMO"]):
    plt.text(v + 0.01, i, f"{v:.3f}", va="center")

plt.xlabel("Valoare KMO")
plt.title("KMO per Variabilă")
plt.legend()
plt.tight_layout()
plt.show()
